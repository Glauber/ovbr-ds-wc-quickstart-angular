import { Component } from '@angular/core';

@Component({
  selector: 'app-relatorio-lancamento',
  templateUrl: './relatorio-lancamento.component.html',
  styleUrls: ['./relatorio-lancamento.component.scss']
})
export class RelatorioLancamentoComponent {
  voltar() {
    throw new Error('Method not implemented.');
  }
  limparDados() {
    throw new Error('Method not implemented.');
  }
  consultar() {
    throw new Error('Method not implemented.');
  }

}
