import { Component } from '@angular/core';

@Component({
  selector: 'app-servicos-lote',
  templateUrl: './servicos-lote.component.html',
  styleUrls: ['./servicos-lote.component.scss']
})
export class ServicosLoteComponent {
  processarListagem() {
    throw new Error('Method not implemented.');
  }
  cancelarLancamentos() {
    throw new Error('Method not implemented.');
  }
  voltar() {
    throw new Error('Method not implemented.');
  }

}
