import { Component } from '@angular/core';

@Component({
  selector: 'app-relatorio-financeiro',
  templateUrl: './relatorio-financeiro.component.html',
  styleUrls: ['./relatorio-financeiro.component.scss']
})
export class RelatorioFinanceiroComponent {
  voltar() {
    throw new Error('Method not implemented.');
  }
  limparDados() {
    throw new Error('Method not implemented.');
  }
  consultar() {
    throw new Error('Method not implemented.');
  }

}
