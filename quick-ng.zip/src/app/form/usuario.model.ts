export class Usuario {
  name: string
  email: string
  mobile: string
  cpf: string
  birthDate: string
  password: string
  rg: string
  address: string
  cep: string
}
